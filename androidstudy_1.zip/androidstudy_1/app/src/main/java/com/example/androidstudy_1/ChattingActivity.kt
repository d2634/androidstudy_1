package com.example.androidstudy_1

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.service_costomer.*

class ChattingActivity : AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chatting)
        setSupportActionBar(toolbar_n)
        supportActionBar!!.setDisplayShowTitleEnabled(false)
    }
}