package com.example.androidstudy_1

class promotion_info (val name: String, val score: String, val more_info: String, val price: String)